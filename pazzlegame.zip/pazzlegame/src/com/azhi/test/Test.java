package com.azhi.test;

import java.util.Random;

public class Test {
    public static void main(String[] args) {
        int[][] newArr = randomArr();
        for (int i = 0; i < newArr.length; i++) {
            for (int j = 0; j < newArr[i].length; j++) {
                System.out.print(newArr[i][j] + " ");
            }
            System.out.println();
        }
    }
    public static int[][] randomArr() {
        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        int[][] doubleArr = new int[4][4];
        Random r = new Random();
        for (int i = 0; i < arr.length; i++) {
            int index = r.nextInt(arr.length);
            int temp = arr[i];
            arr[i] = arr[index];
            arr[index] = temp;
        }
        for (int i = 0; i < arr.length; i++) {
            doubleArr[i / 4][i % 4] = arr[i];
        }
        return doubleArr;
    }
}
