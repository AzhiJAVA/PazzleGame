package com.azhi.test;

public class Test4 {
    public static void main(String[] args) {
        String str = "Hello World";
        change(str);
        System.out.println(str);
    }
    private static void change(String str){
        str = "World";
        System.out.println(str);
    }
}
