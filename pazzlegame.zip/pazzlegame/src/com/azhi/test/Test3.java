package com.azhi.test;

public class Test3 {
    public static void main(String[] args) {
        new MyJFrame3();
    }
}
