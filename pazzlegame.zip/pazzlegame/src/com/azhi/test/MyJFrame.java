package com.azhi.test;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class MyJFrame implements ActionListener {
    JButton jButton = new JButton("点击");
    JButton jButton2 = new JButton("再点击");
    public MyJFrame(){
        JFrame jFrame = new JFrame();
        jFrame.setSize(603,680);
        jFrame.setTitle("事件演示");
        jFrame.setAlwaysOnTop(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);


        jButton.setBounds(0,0,100,50);
        jButton.addActionListener(this);

        jButton2.setBounds(100,0,100,50);
        jButton2.addActionListener(this);

        jFrame.getContentPane().add(jButton);
        jFrame.getContentPane().add(jButton2);

        jFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source == jButton){
            jButton.setSize(200,200);
        } else if (source == jButton2) {
            Random r = new Random();
            jButton2.setLocation(r.nextInt(500),r.nextInt(500));
        }
    }
}
