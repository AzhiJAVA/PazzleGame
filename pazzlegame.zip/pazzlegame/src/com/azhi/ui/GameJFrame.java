package com.azhi.ui;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class GameJFrame extends JFrame implements KeyListener, ActionListener {
    int[][] doubleArr = new int[4][4]; //创建二维数组用于打乱图片
    int x = 0;  //记录空白方块在二维数组中的位置
    int y = 0;
    int count = 0;  //方块移动次数的计数器

    String path = "D:\\JavaCode\\pazzlegame\\image\\animal\\animal7\\"; //定义初始的图片

    //创建代表胜利的二维数组
    int[][] win = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 16}
    };

    //创建选项下面的子功能
    JMenuItem replayItem = new JMenuItem("重置游戏");
    JMenuItem reLoginItem = new JMenuItem("重新登录");
    JMenuItem closeItem = new JMenuItem("关闭游戏");
    JMenuItem girlItem = new JMenuItem("女性");
    JMenuItem animalItem = new JMenuItem("动物");
    JMenuItem sportItem = new JMenuItem("运动");
    JMenuItem wechatItem = new JMenuItem("微信账号");

    //创造一个游戏主界面
    public GameJFrame() {
        initJFrame();  //初始化界面，创建一个宽603像素、高680像素的JFrame窗口

        initJMenuBar(); //初始化菜单

        initData(); //初始化数据

        initImage(); //初始化图片

        this.setVisible(true);  //让窗口可见
    }

    //初始化数据的方法
    private void initData() {
        //打乱一个一维数组
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        Random r = new Random();
        for (int i = 0; i < arr.length; i++) {
            int index = r.nextInt(arr.length);
            int temp = arr[i];
            arr[i] = arr[index];
            arr[index] = temp;
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == 0) { //如果遇到元素0，就获取0方块所在的位置
                x = i / 4;
                y = i % 4;
            }
            doubleArr[i / 4][i % 4] = arr[i]; //将一维数组中的元素存入二维数组
        }
    }

    //初始化图片的方法
    private void initImage() {
        this.getContentPane().removeAll(); //清除容器中的所有图像

        //胜利的时候弹出胜利的图片
        if (victory()) {
            ImageIcon win = new ImageIcon("..\\pazzlegame\\image\\win.png");
            JLabel won = new JLabel(win);
            won.setBounds(203, 283, 197, 73);
            this.getContentPane().add(won);
        }

        //创建一个文字容器，显示操作的步数
        JLabel countStep = new JLabel("步数：" + count);
        countStep.setBounds(50, 30, 100, 20);
        this.getContentPane().add(countStep);

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                int number = doubleArr[i][j];
                ImageIcon icon = new ImageIcon(path + number + ".jpg"); //使用图片的路径添加图片
                JLabel jLabel = new JLabel(icon);//创建一个JLabel容器放置图片
                setLayout(null);//取消容器默认的居中设置
                jLabel.setBounds(105 * j + 84, 105 * i + 134, 105, 105);//指定图片出现的位置
                jLabel.setBorder(new BevelBorder(BevelBorder.LOWERED));
                this.getContentPane().add(jLabel);//将容器存储的图片添加到GameJFrame窗体中的隐藏容器中
            }
        }

        //设置游戏的背景图片
        ImageIcon background = new ImageIcon("..\\pazzlegame\\image\\background.png");
        JLabel backGround = new JLabel(background);
        backGround.setBounds(40, 40, 500, 560);
        this.getContentPane().add(backGround);

        this.getContentPane().repaint(); //重绘容器中的图像
    }

    //初始化界面的方法
    private void initJMenuBar() {
        JMenuBar jMenuBar = new JMenuBar();  //创建菜单对象

        //创建菜单上的两个选项的对象
        JMenu funtionJMenu = new JMenu("功能");
        JMenu aboutJMenu2 = new JMenu("关于我们");
        JMenu changeMenu3 = new JMenu("更换图片");


        //将子功能添加到选项当中
        funtionJMenu.add(replayItem);
        funtionJMenu.add(reLoginItem);
        funtionJMenu.add(closeItem);
        funtionJMenu.add(changeMenu3); //Menu嵌套进入Menu

        aboutJMenu2.add(wechatItem);

        changeMenu3.add(girlItem);
        changeMenu3.add(animalItem);
        changeMenu3.add(sportItem);

        //给条目绑定事件
        replayItem.addActionListener(this);
        reLoginItem.addActionListener(this);
        closeItem.addActionListener(this);
        wechatItem.addActionListener(this);
        girlItem.addActionListener(this);
        animalItem.addActionListener(this);
        sportItem.addActionListener(this);

        //将选项放在窗口上面
        jMenuBar.add(funtionJMenu);
        jMenuBar.add(aboutJMenu2);
        this.setJMenuBar(jMenuBar);
    }

    //初始化菜单的方法
    private void initJFrame() {
        this.setSize(603, 680);

        this.setTitle("阿智拼图游戏 v1.0"); //设置窗口的标题

        this.setAlwaysOnTop(true);  //将游戏窗口始终置于第一优先级

        this.setLocationRelativeTo(null); //将画面初始居中

        this.addKeyListener(this);  //加入键盘监听功能

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置点击 X 时，程序也会随之停止
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    //按下按键不松时的方法
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode(); //定义一个整数获取按键的信息
        if (code == 65) { //如果按下的是65（A），就显示完整的图片
            this.getContentPane().removeAll();
            ImageIcon removeall = new ImageIcon(path + "all.jpg");
            JLabel removeAll = new JLabel(removeall);
            removeAll.setBounds(83, 134, 420, 420);
            this.getContentPane().add(removeAll);
        }

        ImageIcon background = new ImageIcon("..\\pazzlegame\\image\\background.png");
        JLabel backGround = new JLabel(background);
        backGround.setBounds(40, 40, 500, 560);
        this.getContentPane().add(backGround);

        this.getContentPane().repaint();
    }

    //松开按键时的方法
    @Override
    public void keyReleased(KeyEvent e) {
        if (victory()) {  //若胜利了，便不监听按键释放
            return;
        }
        int code = e.getKeyCode();
        if (code == 37) { //如果按键是37（方向键左）
            if (y == 3) { //无法再移动时，直接结束此移动方法
                return;
            }
            doubleArr[x][y] = doubleArr[x][y + 1];
            doubleArr[x][y + 1] = 0;
            y++;
            System.out.println("向左移动");
            count++;
            initImage();
        } else if (code == 38) {
            if (x == 3) {
                return;
            }
            doubleArr[x][y] = doubleArr[x + 1][y];
            doubleArr[x + 1][y] = 0;
            x++;
            System.out.println("向上移动");
            count++;
            initImage();
        } else if (code == 39) {
            if (y == 0) {
                return;
            }
            doubleArr[x][y] = doubleArr[x][y - 1];
            doubleArr[x][y - 1] = 0;
            y--;
            System.out.println("向右移动");
            count++;
            initImage();
        } else if (code == 40) {
            if (x == 0) {
                return;
            }
            doubleArr[x][y] = doubleArr[x - 1][y];
            doubleArr[x - 1][y] = 0;
            x--;
            System.out.println("向下移动");
            count++;
            initImage();
        } else if (code == 65) { //当松开按键A时，重新加载之前的图片
            initImage();
        } else if (code == 87) {  //一键通关，创造新数组覆盖
            doubleArr = new int[][]{
                    {1, 2, 3, 4},
                    {5, 6, 7, 8},
                    {9, 10, 11, 12},
                    {13, 14, 15, 16}
            };
            initImage();
        }
    }

    //判断游戏是否胜利的方法
    public boolean victory() {
        for (int i = 0; i < doubleArr.length; i++) {
            for (int j = 0; j < doubleArr[i].length; j++) {
                if (doubleArr[i][j] != win[i][j]) {
                    return false;  //若有一个数据不一样，return false
                }
            }
        }
        return true;
    }

    //对顶部菜单进行动作监听
    @Override
    public void actionPerformed(ActionEvent e) {
        Object object = e.getSource();
        Random r = new Random();
        if (object == replayItem) { //重开游戏
            count = 0;
            initData();
            initImage();
        } else if (object == reLoginItem) { //重新登陆
            this.setVisible(false);
            new LoginJFrame();
        } else if (object == closeItem) { //关闭游戏
            System.exit(0);  //直接关闭虚拟机
        } else if (object == wechatItem) {  //微信号弹窗
            JDialog jDialog = new JDialog();
            JLabel jLabel = new JLabel(new ImageIcon("..\\pazzlegame\\image\\about.jpg"));
            jLabel.setBounds(0, 0, 258, 258);
            jDialog.getContentPane().add(jLabel);
            jDialog.setSize(344, 344); //设置弹框的大小
            jDialog.setAlwaysOnTop(true);//让弹框置顶
            jDialog.setLocationRelativeTo(null);//让弹框居中
            jDialog.setModal(true);//弹框弹出时，无法操作其他界面
            jDialog.setVisible(true);//弹框可见
        } else if (object == girlItem) { //更换女生图片的功能按键
            int girlIndex = r.nextInt(13) + 1;
            path = "..\\pazzlegame\\image\\girl\\girl" + girlIndex + "\\";
            count = 0;
            initData();
            initImage();
        } else if (object == animalItem) { //更换动物图片的功能按键
            int animalIndex = r.nextInt(8) + 1;
            path = "..\\pazzlegame\\image\\animal\\animal" + animalIndex + "\\";
            count = 0;
            initData();
            initImage();
        } else if (object == sportItem) { //更换运动图片的功能按键
            int sportIndex = r.nextInt(10) + 1;
            path = "D:\\JavaCode\\pazzlegame\\image\\sport\\sport" + sportIndex + "\\";
            count = 0;
            initData();
            initImage();
        }
    }
}
