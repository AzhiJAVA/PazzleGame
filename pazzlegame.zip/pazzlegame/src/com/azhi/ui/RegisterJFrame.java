package com.azhi.ui;

import com.azhi.userInfo.User;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class RegisterJFrame extends JFrame implements MouseListener {
    User user = new User(); //注册，创建新的用户对象
    JTextField passWord = new JTextField();
    JButton registerButton = new JButton(new ImageIcon("..\\pazzlegame\\image\\register\\注册按钮.png"));
    JButton scanAgain = new JButton(new ImageIcon("..\\pazzlegame\\image\\register\\重置按钮.png"));
    JTextField checkPassWord = new JTextField();
    JTextField userName = new JTextField();

    public RegisterJFrame(){

        initJFrame();
        initImage();
        this.setVisible(true);  //让窗口可见
    }


    //创建一个注册界面
    public void initJFrame(){
        this.setSize(488,445);

        this.setTitle("阿智拼图 注册"); //设置窗口的标题

        this.setAlwaysOnTop(true);  //将游戏窗口始终置于第一优先级

        this.setLayout(null);//取消默认布局

        this.setLocationRelativeTo(null); //将画面初始居中

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置点击 X 时，程序也会随之停止
    }

    //注册页面组件显示
    public void initImage(){
        //用户名图片
        JLabel username = new JLabel(new ImageIcon("..\\pazzlegame\\image\\register\\注册用户名.png"));
        username.setBounds(100, 120, 100, 17);
        this.getContentPane().add(username);

        //用户名文本框
        userName.setBounds(210, 120, 200, 30);
        this.getContentPane().add(userName);

        //密码图片
        JLabel password = new JLabel(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\密码.png"));
        password.setBounds(100, 200, 100, 16);
        this.getContentPane().add(password);

        //密码文本框
        passWord.setBounds(210, 200, 200, 30);
        this.getContentPane().add(passWord);

        //再次确认密码图片
        JLabel checkPassword = new JLabel(new ImageIcon("..\\pazzlegame\\image\\register\\再次输入密码.png"));
        checkPassword.setBounds(100, 280, 100, 16);
        this.getContentPane().add(checkPassword);

        //再次确认密码文本框
        checkPassWord.setBounds(210,280, 200, 30);
        this.getContentPane().add(checkPassWord);

        //注册按钮
        registerButton.setBounds(133, 340, 90, 40);
        registerButton.addMouseListener(this);
        this.getContentPane().add(registerButton);

        //重置按钮
        scanAgain.setBounds(256, 340, 90, 40);
        scanAgain.addMouseListener(this);
        this.getContentPane().add(scanAgain);

        //背景图片
        JLabel background = new JLabel(new ImageIcon("..\\pazzlegame\\image\\register\\background.png"));
        background.setBounds(0, 0, 470, 390);
        this.getContentPane().add(background);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    //鼠标长按逻辑，按下用setIcon更换图片达到深色效果
    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getSource() == registerButton) {
            registerButton.setIcon(new ImageIcon("..\\pazzlegame\\image\\register\\注册按下.png"));
        } else if (e.getSource() == scanAgain) {
            scanAgain.setIcon(new ImageIcon("..\\pazzlegame\\image\\register\\重置按下.png"));
        }
    }

    /*鼠标放开逻辑 1：按下注册按钮，若两次输入的密码不相同，弹出不一致弹窗
                 2：若两次输入的密码相同，set方法将数据录入用户对象，加入登录的用户集合，跳转至登录界面
                 3：若点击重置按钮，清除文本框中的全部信息
     */
    @Override
    public void mouseReleased(MouseEvent e) {
        boolean flag = contains(passWord.getText(),checkPassWord.getText());
        if(e.getSource() == registerButton){
            if(flag){
                user.setUsername(userName.getText()); //set用户的用户名
                user.setPassword(checkPassWord.getText()); //set用户的密码
                LoginJFrame.list.add(user); //加入进登录的用户集合
                succeedJFrame(); //弹出注册成功的弹窗
                this.setVisible(false); //关闭注册页面
                new LoginJFrame();//打开登录界面
            }else{
                failJFrame(); //弹出密码不一致弹窗
            }
        } else if (e.getSource() == scanAgain) {
            userName.setText(""); //清除用户名文本框
            passWord.setText("");//清除密码文本框
            checkPassWord.setText("");//清除再次输入文本框
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    //确认两次密码是否相同的方法
    public boolean contains(String password,String checkPassword){
        if(passWord.getText().equals(checkPassWord.getText())){
            return true;
        }
        return false;
    }

    //两次密码不一致弹窗
    public void failJFrame() {
        JDialog remind = new JDialog();
        JLabel jLabel = new JLabel("两次输入的密码不一致，注册失败");
        jLabel.setBounds(0, 0, 200, 200);
        remind.getContentPane().add(jLabel);
        remind.setSize(250, 150);
        remind.setTitle("提示弹窗");
        remind.setAlwaysOnTop(true);
        remind.setLocationRelativeTo(null);
        remind.setModal(true);
        remind.setLayout(null);

        remind.setVisible(true);
    }

    //注册成功弹窗
    public void succeedJFrame() {
        JDialog remind = new JDialog();
        JLabel jLabel = new JLabel("注册成功");
        jLabel.setBounds(0, 0, 200, 200);
        remind.getContentPane().add(jLabel);
        remind.setSize(250, 150);
        remind.setTitle("提示弹窗");
        remind.setAlwaysOnTop(true);
        remind.setLocationRelativeTo(null);
        remind.setModal(true);
        remind.setLayout(null);

        remind.setVisible(true);
    }
}
