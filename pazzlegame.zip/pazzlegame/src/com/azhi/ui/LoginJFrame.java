package com.azhi.ui;

import com.azhi.userInfo.User;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Random;

public class LoginJFrame extends JFrame implements MouseListener {

    public static ArrayList<User> list = new ArrayList<>(); //创建用户集合，存储用户信息

    static {  //事先存储静态用户数据，可以直接登录
        list.add(new User("Yuki", "1234"));
        list.add(new User("Linda", "1234"));
    }


    JButton loginButton = new JButton(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\登录按钮.png"));
    JButton registerButton = new JButton(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\注册按钮.png"));
    JTextField passWord = new JTextField(); //密码文本框
    JTextField captCha = new JTextField();  //验证码文本框
    JTextField userName = new JTextField(); //用户名文本框
    String getCaptcha = captcha(); //定义字符串获取生成的验证码

    public LoginJFrame() {
        initJFrame();
        initImage();
        this.setVisible(true);
    }

    //创建一个登录界面
    private void initJFrame() {
        this.setSize(488, 430);

        this.setTitle("阿智拼图 登录"); //设置窗口的标题

        this.setAlwaysOnTop(true);  //将游戏窗口始终置于第一优先级

        this.setLocationRelativeTo(null); //将画面初始居中

        this.setLayout(null);

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置点击 X 时，程序也会随之停止

    }

    //设置显示页面的各种组件
    private void initImage() {
        //用户名图片
        JLabel username = new JLabel(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\用户名.png"));
        username.setBounds(116, 135, 47, 17);
        this.getContentPane().add(username);

        //用户名文本框设置
        userName.setBounds(195, 134, 200, 30);
        this.getContentPane().add(userName);

        //密码图片
        JLabel password = new JLabel(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\密码.png"));
        password.setBounds(130, 195, 32, 16);
        this.getContentPane().add(password);

        //密码文本框
        passWord.setBounds(195, 195, 200, 30);
        this.getContentPane().add(passWord);

        //验证码图片
        JLabel captcha = new JLabel(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\验证码.png"));
        captcha.setBounds(133, 256, 50, 30);
        this.getContentPane().add(captcha);

        //验证码文本框
        captCha.setBounds(195, 256, 100, 30);
        this.getContentPane().add(captCha);

        //登录按键
        loginButton.setBounds(133, 300, 90, 40);
        loginButton.addMouseListener(this);
        this.getContentPane().add(loginButton);

        //注册按键
        registerButton.setBounds(256, 300, 90, 40);
        registerButton.addMouseListener(this);
        this.getContentPane().add(registerButton);

        //验证码显示
        JLabel captchaView = new JLabel(getCaptcha);
        captchaView.setBounds(300, 243, 50, 50);
        this.getContentPane().add(captchaView);

        //背景设置
        JLabel background = new JLabel(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\background.png"));
        background.setBounds(0, 0, 470, 390);
        this.getContentPane().add(background);

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    //鼠标按住不放逻辑，setIcon更换图片实现深色效果
    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getSource() == loginButton) {
            loginButton.setIcon(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\登录按下.png"));
        } else if (e.getSource() == registerButton) {
            registerButton.setIcon(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\注册按下.png"));
        }
    }


    /*鼠标松开逻辑效果1：验证码出错 弹出验证码出错弹窗，用户再次输入
                   2：验证码正确，判断用户名密码，不正确，弹出出错弹窗
                                            正确 ，进入游戏界面
                   3：点击注册按钮，进入注册页面
     */
    @Override
    public void mouseReleased(MouseEvent e) {
        if (e.getSource() == loginButton) {
            loginButton.setIcon(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\登录按钮.png"));
            boolean flag = contains(list, userName.getText(), passWord.getText()); //调用方法，判断用户名密码是否正确
            if (checkCaptcha()) { //调用检查验证码是否正确方法
                if (flag) {
                    this.setVisible(false); //关闭登录页面
                    new GameJFrame();//打开游戏页面
                } else {
                    remindJFrame();//弹出用户名密码错误弹窗
                }
            } else {
                wrongCaptcha();//弹出验证码出错弹窗
            }
        } else if (e.getSource() == registerButton) { //如果按下注册按钮
            registerButton.setIcon(new ImageIcon("D:\\JavaCode\\pazzlegame\\image\\login\\注册按钮.png"));
            this.setVisible(false); //关闭登录页面
            new RegisterJFrame();//打开注册页面
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    //判断用户名密码是否正确的方法
    public boolean contains(ArrayList<User> list, String username, String password) {
        int index = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getUsername().equals(username)) {
                index = i;
                if (list.get(index).getPassword().equals(password)) {
                    return true;
                }
            }
        }
        return false;
    }

    //生成验证码的方法
    public String captcha() {
        Random r = new Random();
        char[] arr = new char[36];

        //将大写字母加入到字符数组
        for (int i = 0; i < 26; i++) {
            arr[i] = (char) ('A' + i);
        }
        //将数字加入到字符数组
        for (int i = 0; i < 10; i++) {
            arr[26 + i] = (char) ('0' + i);
        }

        char[] captchaArr = new char[5];
        for (int i = 0; i < captchaArr.length; i++) {
            int randomIndex = r.nextInt(36);
            captchaArr[i] = arr[randomIndex];
        }

        String captcha = "";
        for (int i = 0; i < captchaArr.length; i++) {
            captcha += captchaArr[i];
        }

        return captcha;
    }

    //判断验证码是否输入正确方法
    public boolean checkCaptcha() {
        if (captCha.getText().equalsIgnoreCase(getCaptcha)) { //不区分大小写，判断大小写
            return true;
        } else {
            return false;
        }
    }

    //用户名密码出错弹窗方法
    public void remindJFrame() {
        JDialog remind = new JDialog();
        JLabel jLabel = new JLabel("用户名或密码输入错误，请重新输入");
        jLabel.setBounds(0, 0, 200, 200);
        remind.getContentPane().add(jLabel);
        remind.setSize(250, 150);
        remind.setTitle("提示弹窗");
        remind.setAlwaysOnTop(true);
        remind.setLocationRelativeTo(null);
        remind.setModal(true);
        remind.setLayout(null);

        remind.setVisible(true);
    }

    //验证码出错弹窗方法
    public void wrongCaptcha() {
        JDialog remind = new JDialog();
        JLabel jLabel = new JLabel("验证码输入错误，请重新输入");
        jLabel.setBounds(0, 0, 200, 200);
        remind.getContentPane().add(jLabel);
        remind.setSize(250, 150);
        remind.setTitle("提示弹窗");
        remind.setAlwaysOnTop(true);
        remind.setLocationRelativeTo(null);
        remind.setModal(true);
        remind.setLayout(null);

        remind.setVisible(true);
    }
}
