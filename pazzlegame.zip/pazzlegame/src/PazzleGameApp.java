import com.azhi.ui.LoginJFrame;

public class PazzleGameApp {
    public static void main(String[] args) {
        new LoginJFrame(); //登录页面作为游戏入口
    }
}
